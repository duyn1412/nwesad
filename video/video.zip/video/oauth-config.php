<?php
/**
 * YouTube OAuth2 Configuration
 * Update these values with your Google Cloud Console credentials
 */

// OAuth2 Configuration
define('YOUTUBE_CLIENT_ID', '956231274795-kv1d04chd5nq10uah7est0ucbcdvgamt.apps.googleusercontent.com');
define('YOUTUBE_CLIENT_SECRET', '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');
define('YOUTUBE_REDIRECT_URI', 'https://www.nwengineeringllc.com/nwesadmin/video/oauth-callback.php');

// YouTube API Scopes needed for transcript access
define('YOUTUBE_SCOPES', [
    'https://www.googleapis.com/auth/youtube.force-ssl',
    'https://www.googleapis.com/auth/youtube.readonly'
]);

// OAuth2 Authorization URL
define('YOUTUBE_AUTH_URL', 'https://accounts.google.com/o/oauth2/v2/auth');

/**
 * Generate OAuth2 Authorization URL
 */
function getYouTubeAuthUrl() {
    $params = [
        'client_id' => YOUTUBE_CLIENT_ID,
        'redirect_uri' => YOUTUBE_REDIRECT_URI,
        'scope' => implode(' ', YOUTUBE_SCOPES),
        'response_type' => 'code',
        'access_type' => 'offline',
        'prompt' => 'consent'
    ];
    
    return YOUTUBE_AUTH_URL . '?' . http_build_query($params);
}

/**
 * Check if user has valid OAuth2 tokens
 */
function hasValidYouTubeTokens() {
    if (!isset($_SESSION['youtube_access_token'])) {
        return false;
    }
    
    // Check if token is expired
    if (isset($_SESSION['youtube_token_expires']) && time() > $_SESSION['youtube_token_expires']) {
        return false;
    }
    
    return true;
}

/**
 * Get current access token
 */
function getYouTubeAccessToken() {
    if (hasValidYouTubeTokens()) {
        return $_SESSION['youtube_access_token'];
    }
    
    // Try to refresh token if expired
    if (isset($_SESSION['youtube_refresh_token'])) {
        $newToken = refreshYouTubeToken($_SESSION['youtube_refresh_token']);
        if ($newToken) {
            return $newToken;
        }
    }
    
    return null;
}

/**
 * Refresh access token using refresh token
 */
function refreshYouTubeToken($refreshToken) {
    $tokenUrl = 'https://oauth2.googleapis.com/token';
    $postData = [
        'client_id' => YOUTUBE_CLIENT_ID,
        'client_secret' => YOUTUBE_CLIENT_SECRET,
        'refresh_token' => $refreshToken,
        'grant_type' => 'refresh_token'
    ];
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $tokenUrl);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/x-www-form-urlencoded'
    ]);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode === 200) {
        $tokenData = json_decode($response, true);
        
        if (isset($tokenData['access_token'])) {
            // Update session with new token
            $_SESSION['youtube_access_token'] = $tokenData['access_token'];
            $_SESSION['youtube_token_expires'] = time() + $tokenData['expires_in'];
            
            return $tokenData['access_token'];
        }
    }
    
    return null;
}

/**
 * Make authenticated request to YouTube API
 */
function makeYouTubeApiRequest($url, $method = 'GET', $data = null) {
    $accessToken = getYouTubeAccessToken();
    
    if (!$accessToken) {
        return ['error' => 'No valid access token available'];
    }
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . $accessToken,
        'Content-Type: application/json'
    ]);
    
    if ($method === 'POST' && $data) {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    }
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode === 200) {
        return json_decode($response, true);
    } else {
        return ['error' => 'HTTP Error: ' . $httpCode, 'response' => $response];
    }
}
?>
